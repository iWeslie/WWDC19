//
//  StoneNode.swift
//  MindTheStone
//
//  Created by Weslie on 2019/3/18.
//  Copyright © 2019 weslie. All rights reserved.
//

import UIKit
import SceneKit

public class StoneNode: SCNNode {
    
    var hit = false
    
	public override init() {
		super.init()
	}
	
	public required init?(coder aDecoder: NSCoder) {
		fatalError("init(coder:) has not been implemented")
	}
	
	public static func spawnStone() -> StoneNode {
		let stoneNode = StoneNode()
		stoneNode.name = "stone"
        
//        let sphere = SCNBox(width: 0.2, height: 0.2, length: 0.2, chamferRadius: 0.01)
		
        let sphere = SCNScene(named: "stone_1.scn")?.rootNode.childNodes.first?.geometry
//        sphere!.firstMaterial?.diffuse.contents = UIColor.white
//        sphere?.firstMaterial?.diffuse.contents = UIImage(named: "stone_1.jpg")
		stoneNode.geometry = sphere
        stoneNode.scale = SCNVector3(x: 0.2, y: 0.2, z: 0.2)
		
		let shape = SCNPhysicsShape(geometry: SCNSphere(radius: 0.25), options: nil)
		stoneNode.physicsBody = SCNPhysicsBody(type: .dynamic, shape: shape)
		stoneNode.physicsBody?.isAffectedByGravity = false
		
		stoneNode.physicsBody?.categoryBitMask = CollisionCategory.stone.rawValue
		stoneNode.physicsBody?.contactTestBitMask = CollisionCategory.lazer.rawValue | CollisionCategory.ship.rawValue
		
		return stoneNode
	}
}
